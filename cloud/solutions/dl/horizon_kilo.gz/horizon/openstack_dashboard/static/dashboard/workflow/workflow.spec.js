(function () {
  'use strict';

  describe('hz.dashboard.workflow module', function () {
    it('should have been defined', function () {
      expect(angular.module('hz.dashboard.workflow')).toBeDefined();
    });
  });

})();
