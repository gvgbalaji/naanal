/* jshint globalstrict: true */
'use strict';
