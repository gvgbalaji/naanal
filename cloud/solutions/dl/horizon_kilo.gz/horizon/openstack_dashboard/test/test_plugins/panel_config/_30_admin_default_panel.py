# The name of the panel to be added to HORIZON_CONFIG. Required.
PANEL = 'defaults'
# The name of the dashboard the PANEL associated with. Required.
PANEL_DASHBOARD = 'admin'
# The name of the panel group the PANEL is associated with.
PANEL_GROUP = 'admin'

# If set, it will update the default panel of the PANEL_DASHBOARD.
DEFAULT_PANEL = 'defaults'
